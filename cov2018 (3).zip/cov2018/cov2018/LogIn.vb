﻿Public Class LogIn

    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        If txtuser.Text = "admin" And txtpass.Text = "admin" Then
            Main_Menu.Show()
            Me.Hide()
        Else
            MsgBox("Sorry, username or password not found", MsgBoxStyle.OkOnly, "Invalid")
        End If
    End Sub

    Private Sub btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear.Click
        txtuser.Text = ""
        txtpass.Text = ""

    End Sub
End Class
